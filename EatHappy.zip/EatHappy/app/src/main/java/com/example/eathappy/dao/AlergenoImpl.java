package com.example.eathappy.dao;

public class AlergenoImpl implements Alergeno  {
	

}
