package com.example.eathappy.dao;

public interface Marca {

	String getNombre();

	void setNombre(String nombre);

	String getDireccion();

	void setDireccion(String direccion);

	Integer getTelefono();

	void setTelefono(Integer telefono);

	String getCif();

	void setCif(String cif);

	String toString();



}