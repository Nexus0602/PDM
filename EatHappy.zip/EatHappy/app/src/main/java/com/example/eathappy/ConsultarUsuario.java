package com.example.eathappy;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.eathappy.dao.RespuestaUsuarioImpl;
import com.example.eathappy.dao.Usuario;
import com.example.eathappy.servicios.ApiServiceBuilder;
import com.example.eathappy.servicios.EatHappyApiInterface;

import java.util.LinkedList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConsultarUsuario extends AppCompatActivity {

    private EatHappyApiInterface apiInterface;
    private Usuario currentUsuario;
    private TextView idUsuarioTextView;
    private TextView nombreUsuarioTextView;
    private TextView apellidosUsuarioTextView;
    private TextView emailUsuarioTextView;
    private TextView contrasenyaUsuarioTextView;
    private TextView alergenosUsuarioTextView;
    private TextView favoritosUsuarioTextView;
    private List<Usuario> listaUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_consultar_usuario);
        listaUsuarios = new LinkedList<>();

        idUsuarioTextView = findViewById(R.id.idUsuario);
        nombreUsuarioTextView = findViewById(R.id.nombreUsuario);
        apellidosUsuarioTextView = findViewById(R.id.apellidosUsuario);
        emailUsuarioTextView = findViewById(R.id.emailUsuario);
        contrasenyaUsuarioTextView = findViewById(R.id.contrasenyaUsuario);
        alergenosUsuarioTextView = findViewById(R.id.alergenosUsuario);
        favoritosUsuarioTextView = findViewById(R.id.favoritosUsuario);


        Intent intent = getIntent();
        if (intent.hasExtra("usuario")){
            String id = intent.getStringExtra("usuario");
            apiInterface = ApiServiceBuilder.getClient().create(EatHappyApiInterface.class);
            consultarUsuario(id);
            //Log.i("onCreate-dentro del intent", currentUsuario.toString() );
        }
    };

    public void consultarUsuario(String id) {

        Call<RespuestaUsuarioImpl> call = apiInterface.getUsuario(id);
        call.enqueue(new Callback<RespuestaUsuarioImpl>() {
            @Override
            public void onResponse(Call<RespuestaUsuarioImpl> call, Response<RespuestaUsuarioImpl> response) {
                if(response.isSuccessful() && response.body() != null){
                    RespuestaUsuarioImpl respuestaUsuario = response.body();
                    String code = respuestaUsuario.getCode();
                    if (code.equalsIgnoreCase("ok")){
                        listaUsuarios.clear();
                        listaUsuarios.addAll(respuestaUsuario.getResult());
                        for (Usuario u : respuestaUsuario.getResult()) {
                            Log.i("onResponse",u.toString());
                        }

                        currentUsuario =listaUsuarios.get(0);
                        idUsuarioTextView.setText(currentUsuario.getId().toString());
                        nombreUsuarioTextView.setText(currentUsuario.getNombre());
                        apellidosUsuarioTextView.setText(currentUsuario.getApellidos());
                        emailUsuarioTextView.setText(currentUsuario.getEmail());
                        contrasenyaUsuarioTextView.setText(currentUsuario.getContrasenya());
                        if (currentUsuario.getAlergenos()!=null)
                            alergenosUsuarioTextView.setText(currentUsuario.getAlergenos().toString());
                        else
                            alergenosUsuarioTextView.setText("");
                        if (currentUsuario.getFavoritos()!=null)
                            favoritosUsuarioTextView.setText(currentUsuario.getFavoritos().toString());
                        else
                            favoritosUsuarioTextView.setText("");
                    } else {
                        Toast.makeText(ConsultarUsuario.this, "Error: " + respuestaUsuario.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<RespuestaUsuarioImpl> call, Throwable t) {
                Toast.makeText(ConsultarUsuario.this, "Error en la llamada", Toast.LENGTH_SHORT).show();
                Log.e("onFailure", "Error en la llamada " + t.toString());
            }



        });


    }

};
