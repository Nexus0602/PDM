package com.example.eathappy.dao;

public interface Alergeno {

	public enum tipoAlergeno {
	GLUTEN,
    CRUSTACEOS,
    HUEVOS,
    PESCADO,
    CACAHUETES,
    SOJA,
    LACTOSA,
    FRUTOS_SECOS,
    APIO,
    MOSTAZA,
    SESAMO,
    FRUCTOSA,
    SULFITOS,
    MOLUSCOS; }

}