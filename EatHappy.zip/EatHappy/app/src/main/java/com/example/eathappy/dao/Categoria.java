package com.example.eathappy.dao;

public interface Categoria{
	
	
	String getNombre();
    void setNombre(String nombre);

    String getDescripcion();
    void setDescripcion(String descripcion);



}