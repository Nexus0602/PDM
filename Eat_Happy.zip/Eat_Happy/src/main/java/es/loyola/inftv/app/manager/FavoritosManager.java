package es.loyola.inftv.app.manager;

import java.util.List;

import es.loyola.inftv.app.dao.Favorito;

public class FavoritosManager {
	
	public static List<Favorito> getListadoFavoritos(){
		
		
		return null;


}
	}
