package es.loyola.inftv.app.dao;

public class AlergenoImpl implements Alergeno  {
	

}
