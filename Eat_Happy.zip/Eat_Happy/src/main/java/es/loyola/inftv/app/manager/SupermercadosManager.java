package es.loyola.inftv.app.manager;

import java.util.LinkedList;
import java.util.List;


import es.loyola.inftv.app.dao.Supermercado;
import es.loyola.inftv.app.dao.SupermercadoImpl;


public class SupermercadosManager {
	
public static List<Supermercado> getListadoSupermercados(){
	
	List<Supermercado> res = new LinkedList<Supermercado>();
	return res;
	
		/*List<Producto> prods1 = new LinkedList<ProductoImpl>();
		List<Producto> prods2 = new LinkedList<ProductoImpl>();
		
		ProductoImpl p1 = new ProductoImpl ("leche",1);
		ProductoImpl p2 = new ProductoImpl ("pasta",2);
		ProductoImpl p3 = new ProductoImpl ("huevos",3);
		ProductoImpl p4 = new ProductoImpl ("yogurt",4);
		ProductoImpl p5 = new ProductoImpl ("leche de soja",5);
		
		prods1.add(p5);
		prods1.add(p2);
		prods1.add(p3);
		
		prods2.add(p1);
		prods2.add(p4);
		prods2.add(p2);
		
		
		List<SupermercadoImpl> res = new LinkedList<SupermercadoImpl>();
		
		SupermercadoImpl u1 = new SupermercadoImpl("Mercadona", 1, prods1, "Sevilla");
		SupermercadoImpl u2 = new SupermercadoImpl("Mas", 2, prods2, "Sevilla");
		SupermercadoImpl u3 = new SupermercadoImpl("Lidl",3, prods1, "Cadiz");
		
		
		res.add(u1);
		res.add(u2);
		res.add(u3);

		
	 	return res;*/
		
	}

}
