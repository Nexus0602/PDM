package es.loyola.inftv.app.manager;

import java.util.List;

import es.loyola.inftv.app.dao.Opinion;

public class OpinionesManager {
public static List<Opinion> getListadoOpiniones(){
		
		
		return null;


}

}
